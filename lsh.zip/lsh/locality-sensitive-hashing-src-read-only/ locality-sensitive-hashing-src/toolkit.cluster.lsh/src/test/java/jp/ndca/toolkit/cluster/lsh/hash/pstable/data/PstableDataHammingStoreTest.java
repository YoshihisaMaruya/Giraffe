package jp.ndca.toolkit.cluster.lsh.hash.pstable.data;

import static org.junit.Assert.assertEquals;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.junit.Test;

import jp.ndca.toolkit.cluster.lsh.hash.HashProbability;
import jp.ndca.toolkit.cluster.lsh.hash.pstable.NormalHashFunctionHandler;
import jp.ndca.toolkit.cluster.lsh.hash.pstable.NormalHashProbability;
import jp.ndca.toolkit.cluster.lsh.hash.pstable.PstableHandler;
import jp.ndca.toolkit.cluster.lsh.hash.pstable.PstableHandlerWrapper;
import jp.ndca.toolkit.cluster.lsh.hash.pstable.data.PstableHammingDataStore;

public class PstableDataHammingStoreTest {
	
	
	@Test
	public void testSearch() throws IOException{
		
		/**
		 * ベクトルデータの読み込み
		 */
		InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("lsh.txt");
		BufferedReader br = new BufferedReader( new InputStreamReader(is) );
		
		List<int[]> vectorList = new ArrayList<int[]>();
		
		while( br.ready() ){
			String line = br.readLine();
			line = line.substring(1);                  //[を除去
			line = line.substring(0, line.length()-1); //]を除去
			String[] numbers = line.split(",");
			if(numbers.length != 0)
				vectorList.add( StringArrayToIntegerArray(numbers) );
		}
		
		System.out.println("mst_data_size = " + vectorList.size());
		
		/**
		 * LSHパラメータの取得
		 */
		Properties prop = new Properties();
		prop.load( Thread.currentThread().getContextClassLoader().getResourceAsStream("lsh.properties") );

		
		double c = Double.valueOf(prop.getProperty("c"));
		double r = Double.valueOf(prop.getProperty("r"));
		
		System.out.println("c = " + c);
		System.out.println("r = " + r);
			
		HashProbability pp = new NormalHashProbability( c, r );
		double p1 = pp.getGoodHashProb();
		double p2 = pp.getBadHashProb();

		System.out.println("p1 = " + p1);
		System.out.println("p2 = " + p2);
		
		int n = Integer.parseInt(prop.getProperty("n"));
		int dimension = Integer.parseInt(prop.getProperty("dimension"));
		
		PstableHandler ph = new NormalHashFunctionHandler( p1, p2, n, dimension, r );
		
		int K = ph.getK();
		int L = ph.getL();
		
		
		System.out.println("K = " + K);
		System.out.println("L = " + L);

		/**
		 * 検索データの変換
		 */
		long start = System.currentTimeMillis();
		PstableHandlerWrapper phw = new PstableHandlerWrapper( ph.generateHashFunctionVectorGeneratorList( K, L ) );
		PstableHammingDataStore pstableDataHammingStore = new PstableHammingDataStore( vectorList, phw );
		System.out.println("hash table size = "  + pstableDataHammingStore.size());
		long end = System.currentTimeMillis();
		long diff = end - start;
		System.out.println(diff);
		/**
		 * 検索の実行
		 */
		int[] query = new int[]{10, 59, 71, 84, 198, 207, 218, 228, 244, 311, 320, 329, 344, 354, 384, 418, 467};

		 start = System.currentTimeMillis();
		String[] pstableHashes =  phw.getPstableHashes(query);
		int[] result = pstableDataHammingStore.search(pstableHashes);
		 end = System.currentTimeMillis();
		 diff = end - start;
		
		//assertEquals( true, classify(result, 9) );
		System.out.println("result = ");
		for(int re : result){
			System.out.print(re + ",");
		}
		System.out.println();
		System.out.println("result length =" + result.length);
		System.out.println("total time = " + diff +"ms" );	
	}
	
	private static int[] StringArrayToIntegerArray( String[] array ){
		int[] intArray = new int[ array.length ];
			for( int i = 0 ; i < array.length ; i++){
				if(array[i].equals(""))
					continue;
				intArray[i] = Integer.parseInt( array[i].trim() );
			}
		return intArray;
	}
	
	private static boolean classify( int[] candidateIds, int id ){
		for( int candidateId : candidateIds){
			if(candidateId==id)
				return true;
		}
		return false;
	}

}
